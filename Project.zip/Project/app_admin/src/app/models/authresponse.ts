export class AuthResponse {
    token: string
}
